[How to launch]

$ roscd deu_car
$ source ./gazebo_env.sh
$ roslaunch deu_car car_test_map.launch

